"use server";

/* ------------------------------------------------------------------ */
/* Supervisor training server actions.                                  */
/*                                                                      */
/* Every action resolves the supervisor context FROM THE SESSION        */
/* (requireSupervisorContext) — no client-supplied identity, no         */
/* client-supplied school. The service layer re-verifies tenant scope   */
/* on every record (fail-closed).                                       */
/* ------------------------------------------------------------------ */

import { requireSupervisorContext } from "@/lib/supervision/training";
import { deleteSupervisorTraining } from "@/lib/supervision/training-delete";
import {
  addSupervisorQuestion,
  createSupervisorAssessment,
  createSupervisorCourse,
  createSupervisorImpactSurvey,
  deleteSupervisorLesson,
  deleteSupervisorQuestion,
  deleteSupervisorSection,
  deleteSupervisorTrainingAttachment,
  editSupervisorQuestion,
  enrollSupervisorTeachers,
  moveSupervisorLesson,
  moveSupervisorQuestion,
  moveSupervisorSection,
  publishSupervisorTraining,
  saveSupervisorCoursePolicy,
  saveSupervisorLesson,
  saveSupervisorSection,
  saveSupervisorTraining,
  setSupervisorAssessmentPassingPercent,
  setSupervisorAssessmentStatus,
  setSupervisorCourseStatus,
  setSupervisorImpactSurveyStatus,
  setSupervisorLessonPublished,
  updateSupervisorAssessment,
  updateSupervisorCourse,
} from "@/lib/supervision/training";

export async function createSupervisorCourseAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return createSupervisorCourse(ctx, input);
}

export async function updateSupervisorCourseAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return updateSupervisorCourse(ctx, input);
}

export async function setSupervisorCourseStatusAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return setSupervisorCourseStatus(ctx, input);
}

export async function saveSupervisorSectionAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return saveSupervisorSection(ctx, input);
}

export async function deleteSupervisorSectionAction(sectionId: string) {
  const ctx = await requireSupervisorContext();
  return deleteSupervisorSection(ctx, sectionId);
}

export async function moveSupervisorSectionAction(sectionId: string, direction: "up" | "down") {
  const ctx = await requireSupervisorContext();
  return moveSupervisorSection(ctx, sectionId, direction);
}

export async function saveSupervisorLessonAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return saveSupervisorLesson(ctx, input);
}

export async function saveSupervisorCoursePolicyAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return saveSupervisorCoursePolicy(ctx, input);
}

export async function deleteSupervisorLessonAction(lessonId: string) {
  const ctx = await requireSupervisorContext();
  return deleteSupervisorLesson(ctx, lessonId);
}

export async function moveSupervisorLessonAction(lessonId: string, direction: "up" | "down") {
  const ctx = await requireSupervisorContext();
  return moveSupervisorLesson(ctx, lessonId, direction);
}

export async function setSupervisorLessonPublishedAction(lessonId: string, isPublished: boolean) {
  const ctx = await requireSupervisorContext();
  return setSupervisorLessonPublished(ctx, lessonId, isPublished);
}

export async function enrollSupervisorTeachersAction(courseId: string, teacherIds: string[]) {
  const ctx = await requireSupervisorContext();
  return enrollSupervisorTeachers(ctx, courseId, teacherIds);
}

export async function createSupervisorAssessmentAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return createSupervisorAssessment(ctx, input);
}

export async function updateSupervisorAssessmentAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return updateSupervisorAssessment(ctx, input);
}

export async function setSupervisorAssessmentStatusAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return setSupervisorAssessmentStatus(ctx, input);
}

export async function addSupervisorQuestionAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return addSupervisorQuestion(ctx, input);
}

export async function editSupervisorQuestionAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return editSupervisorQuestion(ctx, input);
}

export async function deleteSupervisorQuestionAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return deleteSupervisorQuestion(ctx, input);
}

export async function moveSupervisorQuestionAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return moveSupervisorQuestion(ctx, input);
}

export async function createSupervisorImpactSurveyAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return createSupervisorImpactSurvey(ctx, input);
}

export async function setSupervisorImpactSurveyStatusAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return setSupervisorImpactSurveyStatus(ctx, input);
}

/* ------------------------------------------------------------------ */
/* Unified training page actions — one-page authoring + publishing.     */
/* ------------------------------------------------------------------ */

export async function saveSupervisorTrainingAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return saveSupervisorTraining(ctx, input);
}

export async function deleteSupervisorTrainingAttachmentAction(
  attachmentId: string
) {
  const ctx = await requireSupervisorContext();
  return deleteSupervisorTrainingAttachment(ctx, attachmentId);
}

export async function setSupervisorAssessmentPassingPercentAction(
  input: unknown
) {
  const ctx = await requireSupervisorContext();
  return setSupervisorAssessmentPassingPercent(ctx, input);
}

export async function publishSupervisorTrainingAction(input: unknown) {
  const ctx = await requireSupervisorContext();
  return publishSupervisorTraining(ctx, input);
}

/**
 * PERMANENT training deletion — the session's supervisor context is
 * resolved here and the service re-verifies school ownership inside
 * one transaction (the confirmation word "DELETE" is a client-side
 * safeguard only; the server never relies on it).
 */
export async function deleteSupervisorTrainingAction(courseId: string) {
  const ctx = await requireSupervisorContext();
  return deleteSupervisorTraining(ctx, courseId);
}