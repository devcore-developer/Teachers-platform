﻿# File Collection Report (pre-change snapshot)

- Generated : 2026-11-15 20:06:53
- Project   : D:\DevCore\Teachers-platform
- Output    : D:\DevCore\Teachers-platform\_file-audit-20261115-200652

## Summary

| Group | Meaning | Entries | Found | Missing |
|---|---|---|---|---|
| A | modified by the task (will be replaced) | 6 | 4 | 2 |
| B | brand-new files (missing here is EXPECTED) | 4 | 0 | 4 |
| C | support files (context, not modified) | 26 | 19 | 7 |
| D | discovered by auto-sweep (copied too) | 44 | 44 | 0 |

Copied: **67 files** (560.5 KB) into `files\` - original folder structure preserved.


## A - Files MODIFIED by the task (will be replaced by the new versions)

| # | Path | Status | Size | Lines | Note |
|---|---|---|---|---|---|
| 1 | `src/app/it/assignments/assignments-client.tsx` | [MISSING] | - | - | assignments workspace UI |
| 2 | `src/app/login/page.tsx` | [OK] | 3.4 KB | 90 | login page (forgot link + banner) |
| 3 | `src/app/page.tsx` | [OK] | 2.9 KB | 75 | home dashboard (role switch) |
| 4 | `src/config/navigation.ts` | [OK] | 12.9 KB | 368 | sidebar nav: IT coordinator items |
| 5 | `src/lib/auth/roles.ts` | [OK] | 9.1 KB | 201 | role keys + NAV_ROLES map |
| 6 | `src/lib/it/service.ts` | [MISSING] | - | - | IT service: assign + recovery + stats |

## B - NEW files (MISSING here is EXPECTED - they will be created by the fix)

| # | Path | Status | Size | Lines | Note |
|---|---|---|---|---|---|
| 1 | `src/app/forgot-password/forgot-password-form.tsx` | [MISSING] | - | - | forgot password form |
| 2 | `src/app/forgot-password/page.tsx` | [MISSING] | - | - | forgot password page |
| 3 | `src/app/reset-password/page.tsx` | [MISSING] | - | - | reset password page (token states) |
| 4 | `src/app/reset-password/reset-password-form.tsx` | [MISSING] | - | - | reset password form |

## C - Support files (context only, NOT modified)

| # | Path | Status | Size | Lines | Note |
|---|---|---|---|---|---|
| 1 | `prisma/schema.prisma` | [OK] | 75 KB | 1817 | prisma schema (models) |
| 2 | `src/app/actions/auth.ts` | [OK] | 6.5 KB | 201 | auth server actions |
| 3 | `src/app/actions/it.ts` | [OK] | 2.9 KB | 92 | IT server actions |
| 4 | `src/app/actions/registration-links.ts` | [MISSING] | - | - | registration links actions |
| 5 | `src/app/it/assignments/page.tsx` | [MISSING] | - | - | assignments page (guard+data) |
| 6 | `src/app/it/recovery/page.tsx` | [MISSING] | - | - | recovery page |
| 7 | `src/app/it/recovery/recovery-client.tsx` | [MISSING] | - | - | recovery client UI |
| 8 | `src/app/registration-links/link-manager.tsx` | [MISSING] | - | - | registration links manager UI |
| 9 | `src/app/registration-links/page.tsx` | [MISSING] | - | - | registration links page |
| 10 | `src/app/supervision/dashboard/section.tsx` | [OK] | 12.2 KB | 287 | supervisor dashboard section |
| 11 | `src/components/auth/auth-card.tsx` | [OK] | 5.2 KB | 128 | shared auth card shell |
| 12 | `src/components/dashboard/it-coordinator-dashboard.tsx` | [MISSING] | - | - | IT dashboard component |
| 13 | `src/components/platform/status-badge.tsx` | [OK] | 1.5 KB | 52 | status badge |
| 14 | `src/components/ui/button.tsx` | [OK] | 2.1 KB | 59 | ui button |
| 15 | `src/components/ui/input.tsx` | [OK] | 1 KB | 21 | ui input |
| 16 | `src/lib/auth/dev-admin.ts` | [OK] | 6.4 KB | 187 | dev admin contexts (IT ctx) |
| 17 | `src/lib/auth/one-time-tokens.ts` | [OK] | 5.4 KB | 161 | single-use reset tokens |
| 18 | `src/lib/auth/password.ts` | [OK] | 1.1 KB | 30 | password hashing |
| 19 | `src/lib/auth/rate-limit.ts` | [OK] | 2.6 KB | 70 | login rate limiter |
| 20 | `src/lib/auth/session.ts` | [OK] | 3.7 KB | 112 | session helpers (requireUser) |
| 21 | `src/lib/auth/token.ts` | [OK] | 2.5 KB | 68 | token helpers |
| 22 | `src/lib/branding.ts` | [OK] | 9.3 KB | 260 | public branding resolver |
| 23 | `src/lib/db.ts` | [OK] | 1.2 KB | 32 | prisma client singleton |
| 24 | `src/lib/mail/mailer.ts` | [OK] | 7.1 KB | 161 | mail provider + reset email |
| 25 | `src/lib/types.ts` | [OK] | 4.2 KB | 154 | shared types (NavItem) |
| 26 | `src/lib/validation/it.ts` | [OK] | 2.1 KB | 59 | IT zod schemas |

## D - Discovered related files (auto-sweep, copied for completeness)

| # | Path | Status | Size | Lines | Note |
|---|---|---|---|---|---|
| 1 | `prisma/migrations/0_init/migration.sql` | [OK] | 49.4 KB | 1345 | discovered by auto-sweep |
| 2 | `prisma/migrations/20251106090000_add_attachment_provider/migration.sql` | [OK] | 0.3 KB | 5 | discovered by auto-sweep |
| 3 | `prisma/migrations/20251112120000_unified_training_creation/migration.sql` | [OK] | 0.7 KB | 13 | discovered by auto-sweep |
| 4 | `src/app/account/forgot-password/forgot-password-form.tsx` | [OK] | 2.1 KB | 64 | discovered by auto-sweep |
| 5 | `src/app/account/reset-password/reset-password-form.tsx` | [OK] | 2.6 KB | 73 | discovered by auto-sweep |
| 6 | `src/app/actions/account.ts` | [OK] | 7.1 KB | 169 | discovered by auto-sweep |
| 7 | `src/app/actions/account-security.ts` | [OK] | 3.6 KB | 97 | discovered by auto-sweep |
| 8 | `src/app/actions/archive.ts` | [OK] | 4.3 KB | 109 | discovered by auto-sweep |
| 9 | `src/app/actions/assessment.ts` | [OK] | 11.2 KB | 325 | discovered by auto-sweep |
| 10 | `src/app/actions/assignments.ts` | [OK] | 16.4 KB | 478 | discovered by auto-sweep |
| 11 | `src/app/actions/certificates.ts` | [OK] | 5.5 KB | 158 | discovered by auto-sweep |
| 12 | `src/app/actions/growth.ts` | [OK] | 3.8 KB | 119 | discovered by auto-sweep |
| 13 | `src/app/actions/journey-exam.ts` | [OK] | 10.5 KB | 309 | discovered by auto-sweep |
| 14 | `src/app/actions/learning.ts` | [OK] | 9.3 KB | 258 | discovered by auto-sweep |
| 15 | `src/app/actions/lesson-watch.ts` | [OK] | 2.9 KB | 84 | discovered by auto-sweep |
| 16 | `src/app/actions/media.ts` | [OK] | 16.2 KB | 442 | discovered by auto-sweep |
| 17 | `src/app/actions/messages.ts` | [OK] | 2.7 KB | 76 | discovered by auto-sweep |
| 18 | `src/app/actions/notifications.ts` | [OK] | 3.3 KB | 94 | discovered by auto-sweep |
| 19 | `src/app/actions/platform-settings.ts` | [OK] | 2.9 KB | 88 | discovered by auto-sweep |
| 20 | `src/app/actions/reports.ts` | [OK] | 2.7 KB | 73 | discovered by auto-sweep |
| 21 | `src/app/actions/school-branding.ts` | [OK] | 19.2 KB | 501 | discovered by auto-sweep |
| 22 | `src/app/actions/schools.ts` | [OK] | 4.1 KB | 129 | discovered by auto-sweep |
| 23 | `src/app/actions/staffing.ts` | [OK] | 3.9 KB | 109 | discovered by auto-sweep |
| 24 | `src/app/actions/supervision-training.ts` | [OK] | 6.7 KB | 184 | discovered by auto-sweep |
| 25 | `src/app/actions/surveys.ts` | [OK] | 11.6 KB | 339 | discovered by auto-sweep |
| 26 | `src/app/actions/teacher-profile.ts` | [OK] | 10.1 KB | 282 | discovered by auto-sweep |
| 27 | `src/app/actions/training.ts` | [OK] | 15.2 KB | 461 | discovered by auto-sweep |
| 28 | `src/app/actions/users.ts` | [OK] | 7 KB | 229 | discovered by auto-sweep |
| 29 | `src/app/it/it-forms.tsx` | [OK] | 4.3 KB | 132 | discovered by auto-sweep |
| 30 | `src/app/it/page.tsx` | [OK] | 9.1 KB | 216 | discovered by auto-sweep |
| 31 | `src/app/schools/branding/branding-manager.tsx` | [OK] | 29.4 KB | 733 | discovered by auto-sweep |
| 32 | `src/config/branding.ts` | [OK] | 1.2 KB | 34 | discovered by auto-sweep |
| 33 | `src/lib/auth/tokens.ts` | [OK] | 12.3 KB | 323 | discovered by auto-sweep |
| 34 | `src/lib/security/rate-limit.ts` | [OK] | 2.6 KB | 80 | discovered by auto-sweep |
| 35 | `src/lib/surveys/rate-limit.ts` | [OK] | 0.4 KB | 13 | discovered by auto-sweep |
| 36 | `src/lib/validation/assessment.ts` | [OK] | 15.2 KB | 409 | discovered by auto-sweep |
| 37 | `src/lib/validation/assignments.ts` | [OK] | 10.9 KB | 296 | discovered by auto-sweep |
| 38 | `src/lib/validation/auth.ts` | [OK] | 5.2 KB | 138 | discovered by auto-sweep |
| 39 | `src/lib/validation/certificates.ts` | [OK] | 6.2 KB | 174 | discovered by auto-sweep |
| 40 | `src/lib/validation/schools.ts` | [OK] | 7.3 KB | 197 | discovered by auto-sweep |
| 41 | `src/lib/validation/surveys.ts` | [OK] | 16.9 KB | 445 | discovered by auto-sweep |
| 42 | `src/lib/validation/training.ts` | [OK] | 14 KB | 409 | discovered by auto-sweep |
| 43 | `src/lib/validation/user-fields.ts` | [OK] | 1.8 KB | 43 | discovered by auto-sweep |
| 44 | `src/lib/validation/users.ts` | [OK] | 8 KB | 238 | discovered by auto-sweep |

## Next steps

1. Keep this folder (or the zip) as your backup of the CURRENT originals.
2. Apply the replacement files that were sent to you (group A gets replaced,
   group B files are created new).
3. Re-run this script afterwards to snapshot the new state and compare.

